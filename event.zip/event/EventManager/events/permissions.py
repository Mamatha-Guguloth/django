from rest_framework import permissions

# Permission: Only the organizer can edit or delete an event
class IsOrganizerOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Read permissions allowed for any request
        if request.method in permissions.SAFE_METHODS:
            return True
        # Write permissions only for the organizer
        return obj.organizer == request.user


# Permission: Only invited users or public events can access
class IsInvitedOrPublic(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        # Public events are accessible by everyone
        if obj.is_public:
            return True
        # Private events accessible only to invited users
        return request.user in obj.invited_users.all()
