from celery import shared_task
from django.core.mail import send_mail
from .models import Event

@shared_task
def send_event_notification(event_id, subject, message):
    try:
        event = Event.objects.get(id=event_id)
        recipients = [user.email for user in event.invited_users.all()]
        send_mail(subject, message, 'noreply@example.com', recipients)
    except Event.DoesNotExist:
        pass  # Handle event not found gracefully
