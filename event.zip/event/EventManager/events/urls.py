from django.urls import path
from .views import EventListCreateView, EventDetailView, RSVPCreateView, RSVPUpdateView, ReviewListCreateView

urlpatterns = [
    path('events/', EventListCreateView.as_view(), name='event-list-create'),
    path('events/<int:pk>/', EventDetailView.as_view(), name='event-detail'),
    path('events/<int:event_id>/rsvp/', RSVPCreateView.as_view(), name='rsvp-create'),
    path('events/<int:event_id>/rsvp/<int:user_id>/', RSVPUpdateView.as_view(), name='rsvp-update'),
    path('events/<int:event_id>/reviews/', ReviewListCreateView.as_view(), name='review-list-create'),
]
