from django.contrib import admin
from django.contrib.auth.models import User
from .models import Event, RSVP, Review, UserProfile

# -------------------------
# UserProfile Admin
# -------------------------
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'full_name', 'location')
    search_fields = ('user__username', 'full_name', 'location')

admin.site.register(UserProfile, UserProfileAdmin)

# -------------------------
# Event Admin
# -------------------------
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'organizer', 'location', 'start_time', 'end_time', 'is_public')
    list_filter = ('is_public', 'start_time', 'end_time')
    search_fields = ('title', 'location', 'organizer__username')
    ordering = ('-start_time',)
    filter_horizontal = ('invited_users',)  # If you have many-to-many invited users

admin.site.register(Event, EventAdmin)

# -------------------------
# RSVP Admin
# -------------------------
class RSVPAdmin(admin.ModelAdmin):
    list_display = ('event', 'user', 'status')
    list_filter = ('status',)
    search_fields = ('event__title', 'user__username')

admin.site.register(RSVP, RSVPAdmin)

# -------------------------
# Review Admin
# -------------------------
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('event', 'user', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('event__title', 'user__username', 'comment')

admin.site.register(Review, ReviewAdmin)
