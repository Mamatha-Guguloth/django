from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Event, RSVP, Review, UserProfile

# -------------------------
# UserProfile Serializer
# -------------------------
class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['full_name', 'bio', 'location', 'profile_picture']

# -------------------------
# User Serializer
# -------------------------
class UserSerializer(serializers.ModelSerializer):
    profile = UserProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'profile']

# -------------------------
# Event Serializer
# -------------------------
class EventSerializer(serializers.ModelSerializer):
    organizer = UserSerializer(read_only=True)
    invited_users = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(), many=True, required=False
    )

    class Meta:
        model = Event
        fields = [
            'id', 'title', 'description', 'organizer', 'location',
            'start_time', 'end_time', 'is_public', 'invited_users',
            'created_at', 'updated_at'
        ]

# -------------------------
# RSVP Serializer
# -------------------------
class RSVPSerializer(serializers.ModelSerializer):
    class Meta:
        model = RSVP
        fields = ['id', 'event', 'user', 'status']
        read_only_fields = ['user']  # User is set from request

    def validate(self, attrs):
        event = attrs.get('event')
        user = self.context['request'].user
        if RSVP.objects.filter(event=event, user=user).exists():
            raise serializers.ValidationError("You have already RSVPed to this event.")
        return attrs

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)

# -------------------------
# Review Serializer
# -------------------------
class ReviewSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'event', 'user', 'rating', 'comment', 'created_at']

    def validate_rating(self, value):
        if not (1 <= value <= 5):
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)
